<?php
session_start();
require_once'connection.php';
include 'constant.php';
$conn = new mysqli($server,$user,$pass,$db);
if(isset($_POST['log'])){
  if(!empty($_POST['username']) && !empty($_POST['password'])) {  	
   $username = $_POST['username'];
    $password = $_POST['password'];
    mysqli_select_db($conn, 'cat') or die ("no database"); 
    $sql = ("SELECT * FROM users WHERE User_Name = '$username' AND Password = '$password'") or die("Failed to query database");
    $result = mysqli_query($conn,$sql);
   $row = mysqli_fetch_assoc($result);
    if($row['User_Name']==$username && $row['Password']==$password){
        $_SESSION['username']=$_POST['username'];
        $_SESSION['password']=$_POST['password'];
    	header("location:redirect.php");
    }else{
    	echo "Failed to login due to credentials";
        header("location:login1.html");
    }
     }
     else {  
    echo "Invalid username or password!";  
    }
}
mysqli_close($conn);
?>