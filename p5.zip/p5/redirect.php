<?php
require_once 'login.php';
if(isset($_SESSION['username'])){
	echo "Hello:".$_SESSION['username']."<br>";
}else{
	echo "You need to login to proceed";
	header('location:login1.html');
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Redirect</title>
</head>
<body>
<a href="update.php"><button type="button">Update Profile</button></a> <a href="manage.php"><button type="button">Manage Users</button></a>
<form method="POST" action="action.php">
<input type="submit" name=logout value="Log Out"/>
</form>
<p>Directed here</p>
</body>
</html>