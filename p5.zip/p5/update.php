<?php
require_once 'connection.php';
$conn = new mysqli($server,$user,$pass,$db) or die('Could not connect');
if(isset($_POST['update'])){
$userid = $_POST['userid'];
$fname = $_POST['fname'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$pass = $_POST['pass'];
$usertype = $_POST['usertype'];
$access = $_POST['access'];
$image = $_POST['image'];
$address = $_POST['address'];
  $sql = ("UPDATE users SET userId=$userid, Full_Name=$fname, email=$email, phone_Number=$phone, Password=$pass, UserType=$usertype, AccessTime=$access, Image=$image, Address=$address WHERE userId=$userid");
  if(mysqli_query($conn,$sql)){
  	echo "Success";
  }else{
  	die("Database query failed. ");
  }
}
?>
<html>
<head>
<title>Update Profile</title>
</head>
<body>
<form action="update.php" method="POST">
<fieldset>
UserId:<input type="text" name="userid"><br>
Full Name:<input type="text" name="fname"><br>
Email:<input type="text" name="email"><br>
Phone Number:<input type="text" name="phone"><br>
Password:<input type="password" name="pass"><br>
UserType:<input type="text" name="usertype"><br>
Access Time:<input type="text" name="access"><br>
Image:<input type="text" name="image"><br>
Address:<input type="text" name="address"><br>
<input type="submit" name="update" value="Update">
</fieldset>
</form>
</body>
</html>