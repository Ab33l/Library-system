<?php
session_start();
require_once 'connection.php';
if(isset($_POST['logout'])){
	unset($_SESSION['username']); 
	unset($_SESSION['password']);
	echo "You have successfully logged out";
	header('location:login1.html');
}
else{
	echo "Not logged out";
	header('location:redirect.php');
}
?>