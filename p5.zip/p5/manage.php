<?php
require_once ('connection.php');
$conn = new mysqli($server,$user,$pass,$db) or die('Could not connect');
if(isset($_POST['add'])){
$userid = $_POST['userid'];
$fname = $_POST['fname'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$user = $_POST['user'];
$pass = $_POST['pass'];
$usertype = $_POST['usertype'];
$access = $_POST['access'];
$image = $_POST['image'];
$address = $_POST['address'];
  $sql = "INSERT INTO users (userId, Full_Name, email, phone_Number, User_Name, Password, UserType, AccessTime, Image, Address)
  VALUES('".$_POST["userid"]."', '".$_POST["fname"]."', '".$_POST["email"]."', '".$_POST["phone"]."','".$_POST["user"]."','".$_POST["pass"]."','".$_POST["usertype"]."','".$_POST["access"]."','".$_POST["image"]."','".$_POST["address"]."')";
  if(mysqli_query($conn,$sql)){
  	echo "Success";
  }else{
  	die("Database query failed. ");
  }
  }
  if(isset($_POST['update'])){
$userid = $_POST['userid'];
$fname = $_POST['fname'];
$email = $_POST['email'];
$user = $_POST['user'];
$phone = $_POST['phone'];
$pass = $_POST['pass'];
$usertype = $_POST['usertype'];
$access = $_POST['access'];
$image = $_POST['image'];
$address = $_POST['address'];
  $sql = ("UPDATE users SET userId=$userid, Full_Name=$fname, email=$email, phone_Number=$phone, User_Name=$user, Password=$pass, UserType=$usertype, AccessTime=$access, Image=$image, Address=$address WHERE userId=$userid");
  if(mysqli_query($conn,$sql)){
  	echo "Success";
  }else{
  	die("Database query failed. ");
  }
}
?>
<html>
<head>
<title>Manage Users</title>
<style>
table {
    border-collapse: collapse;
}

table, th, td {
    border: 1px solid black;
}
</style>
</head>
<body>
<form action="manage.php" method="POST">
<fieldset>
UserId:<input type="text" name="userid"><br>
Full Name:<input type="text" name="fname"><br>
Email:<input type="text" name="email"><br>
Phone Number:<input type="text" name="phone"><br>
Username:<input type="text" name="user"><br>
Password:<input type="password" name="pass"><br>
UserType:<input type="text" name="usertype"><br>
Access Time:<input type="text" name="access"><br>
Image:<input type="text" name="image"><br>
Address:<input type="text" name="address"><br>
<input type="submit" name="add" value="Add User">
</fieldset>
</form>
<h2>Update Other User Profile</h2>
<form action="manage.php" method="POST">
<fieldset>
UserId:<input type="text" name="userid"><br>
Full Name:<input type="text" name="fname"><br>
Email:<input type="text" name="email"><br>
Phone Number:<input type="text" name="phone"><br>
UserName:<input type="text" name="phone"><br>
Password:<input type="password" name="pass"><br>
UserType:<input type="text" name="usertype"><br>
Access Time:<input type="text" name="access"><br>
Image:<input type="text" name="image"><br>
Address:<input type="text" name="address"><br>
<input type="submit" name="update" value="Update user profile">
</fieldset>
</form>
<h2>View User records</h2>
<table style="width:100%;text-align:center;">
<tr>
<th>UserId</th>
<th>Full Name</th>
<th>Email</th>
<th>Phone Number</th>
<th>UserName</th>
<th>Access Time</th>
<th>UserType</th>
<th>Image</th>
<th>Address</th>
<th>Password</th>
</tr>
<?php
require_once ('connection.php');
$conn = new mysqli($server,$user,$pass,$db) or die('Could not connect');
$usertype = $_POST['usertype'];
if($usertype = 'Super_User'){
$sql = "SELECT * FROM users";
$result = mysqli_query($conn,$sql);
while($row = mysqli_fetch_assoc($result))
{
	echo "<tr>";
	echo "<td>".$row['userId']."</td>";
	echo "<td>".$row['Full_Name']."</td>";
    echo "<td>".$row['email']."</td>";
    echo "<td>".$row['phone_Number']."</td>";
    echo "<td>".$row['User_Name']."</td>";
    echo "<td>".$row['AccessTime']."</td>";
    echo "<td>".$row['UserType']."</td>";
    echo "<td>".$row['Image']."</td>";
    echo "<td>".$row['Address']."</td>";
    echo "<td>".$row['Password']."</td>";
    echo "</tr>";
}
echo "</table>";
}else{
	header('location:view.php');	
}
?>
<h2>Delete Records from specific userid</h2>
<?php
require_once ('connection.php');
$conn = new mysqli($server,$user,$pass,$db) or die('Could not connect');
if(isset($_POST['delete'])){
$userid = $_POST['userid'];
$sql =  $sql = "DELETE FROM users WHERE userId = $userid" ;
 if(mysqli_query($conn,$sql)){
  	echo "Success";
  }else{
  	die("Database query failed. ");
  }
}else{
 header('location:view.php');	
}
?>
<form method="POST" action="manage.php">
UserId:<input type="text" name="userid"><br>
<input type="submit" name="delete" value="Delete user records">
</form>
</body>
</html>