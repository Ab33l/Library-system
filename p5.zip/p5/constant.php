<?php
$server = 'localhost';
$user = 'root';
$pass = '';
$db = 'cat';
?>