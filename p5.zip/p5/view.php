<html>
<head>
<style>
table {
    border-collapse: collapse;
}

table, th, td {
    border: 1px solid black;
}
</style>
</head>
<body>
<h2>Delete Records from specific userid</h2>
<?php
require_once ('connection.php');
$conn = new mysqli($server,$user,$pass,$db) or die('Could not connect');
if(isset($_POST['delete'])){
$userid = $_POST['userid'];
$sql =  $sql = "DELETE FROM users WHERE userId BETWEEN '10' AND '1000' ";
 if(mysqli_query($conn,$sql)){
  	echo "Success";
  }else{
  	die("Database query failed. ");
  }
}
?>
<form method="POST" action="view.php">
UserId:<input type="text" name="userid"><br>
<input type="submit" name="delete" value="Delete user records">
</form>
<h2>View User records</h2>
<table style="width:100%;text-align:center;">
<tr>
<th>UserId</th>
<th>Full Name</th>
<th>Email</th>
<th>Phone Number</th>
<th>UserName</th>
<th>Access Time</th>
<th>UserType</th>
<th>Image</th>
<th>Address</th>
<th>Password</th>
</tr>
<?php
require_once ('connection.php');
$conn = new mysqli($server,$user,$pass,$db) or die('Could not connect');
$usertype = $_POST['usertype'];
$sql = "SELECT * FROM users WHERE userId BETWEEN '10' AND '1000'";
$result = mysqli_query($conn,$sql);
while($row = mysqli_fetch_assoc($result))
{
	echo "<tr>";
	echo "<td>".$row['userId']."</td>";
	echo "<td>".$row['Full_Name']."</td>";
    echo "<td>".$row['email']."</td>";
    echo "<td>".$row['phone_Number']."</td>";
    echo "<td>".$row['User_Name']."</td>";
    echo "<td>".$row['AccessTime']."</td>";
    echo "<td>".$row['UserType']."</td>";
    echo "<td>".$row['Image']."</td>";
    echo "<td>".$row['Address']."</td>";
    echo "<td>".$row['Password']."</td>";
    echo "</tr>";
}
echo "</table>";
?>
</body>
</html>