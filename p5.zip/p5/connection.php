<?php
require 'constant.php';
$conn = new mysqli($server,$user,$pass,$db) or die('Could not connect');
echo 'Connection successful';

mysqli_close($conn);
?>
